# Lab 3 - Metadata filter, then a search box  (30 minutes: Part A 15 + Part B 15)

**You will be able to:** use a metadata filter so a search only looks in the right place, and put a search behind a small web page with Gradio.

You need Python 3 and this folder. Part B also needs `pip install gradio` (do it now, while you read).

## Part A - the filter (15 minutes)
Every document has a `department` (billing, returns, shipping, technical). Several departments have a document that answers
*"How long does processing take?"* or *"Who do I contact?"* - almost the same words, different department.

### 1. Run it (2 min)
```
python filter_lab.py
```
Look at the last two lines: recall@3 **without** and **with** a department filter. They are the same.
**Write one sentence:** for a billing question, which departments' documents come back?

### 2. Fix it (5 min)
Open `filter_lab.py`. Edit only the line marked `YOUR FIX` inside `search()`:
when `department` is given, only documents whose `"department"` equals it may be candidates. When it is `None`, search everything.

### 3. Verify (3 min)
```
python filter_lab.py --check
```
**Verify that all 3 checks pass.** Then write one sentence: **what is the difference between filtering *before* the ranking and keeping the top 3 *and then* filtering?** (Try it in your head with 4 billing documents and 40 documents from other departments.)

## Part B - a search box in the browser (15 minutes)
Gradio turns a Python function into a web page. You give it three things: the **function**, its **inputs** and its **outputs**.

### 1. Learn the pattern (3 min)
```python
import gradio as gr
def greet(name, shout):
    text = "Hello " + name
    return text.upper() if shout else text
gr.Interface(fn=greet, inputs=[gr.Textbox(label="Name"), gr.Checkbox(label="Shout")], outputs=gr.Textbox()).launch()
```
The inputs list matches the function's arguments **in order**.

### 2. Build it (7 min)
Open `app.py`. The function `find(question, department)` is ready. Fill in the part marked `YOUR FIX`: a `gr.Interface` with
* `fn` = `find`
* `inputs` = a `Textbox` for the question and a `Dropdown` of the departments (with an empty `""` choice that means "all")
* `outputs` = a `gr.Dataframe(headers=["score", "department", "text"])`

### 3. Verify and try it (5 min)
```
python app.py --check
python app.py
```
Open the address it prints. Ask *"Who do I contact?"* with **billing**, then **shipping**, then **empty**. **Write one sentence:** what changed, and why?

## Keep it
Keep `filter_lab.py` and `app.py`. In the last block you can put a search box like this on **your own project's** search.
