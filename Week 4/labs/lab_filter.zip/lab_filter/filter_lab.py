"""
LAB 3 - Metadata filter fix (Part A).  Part B (Gradio) is in app.py.

Run it:            python filter_lab.py
Check your fix:    python filter_lab.py --check
The "model" is the same STAND-IN as Labs 1 and 2.  Only edit the part marked  YOUR FIX.
"""
import json, os, sys, math
from toy_embed import embed

HERE = os.path.dirname(os.path.abspath(__file__))
DOCS = json.load(open(os.path.join(HERE, "kb.json")))                  # [{"id", "department", "text", "vector"}, ...]
QUERIES = json.load(open(os.path.join(HERE, "queries.json")))          # [{"query", "department", "expected"}, ...]
DEPARTMENTS = ["billing", "returns", "shipping", "technical"]


def cosine(a, b):
    d = sum(x * y for x, y in zip(a, b))
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(x * x for x in b))
    return d / (na * nb) if na and nb else 0.0


# ============================================================================
#  YOUR FIX
# ============================================================================
def search(query, department=None, k=3):
    """The k closest documents.  If `department` is given, only documents of THAT department may be returned."""
    candidates = DOCS            # YOUR FIX: when department is given, keep only the documents whose "department" equals it.
    qv = embed(query)
    scored = sorted(((cosine(qv, d["vector"]), d) for d in candidates), key=lambda t: -t[0])
    return scored[:k]


# ============================================================================
#  THE EXPERIMENT  (do not edit)
# ============================================================================
def recall(use_department):
    hits, wrong = 0, []
    for n, q in enumerate(QUERIES, 1):
        res = search(q["query"], q["department"] if use_department else None)
        if q["expected"] in [d["id"] for _, d in res]:
            hits += 1
        else:
            wrong.append(n)
    return hits, wrong


def show():
    for n, q in enumerate(QUERIES, 1):
        res = search(q["query"], q["department"])
        ok = q["expected"] in [d["id"] for _, d in res]
        print("%2d  %-5s [%s] %s" % (n, "OK" if ok else "WRONG", q["department"], q["query"]))
        for s, d in res:
            print("       %.2f  %-9s %s%s" % (s, d["department"], d["text"][:56], "  <- right answer" if d["id"] == q["expected"] else ""))
    h_no, _ = recall(False)
    h_yes, wrong = recall(True)
    print("\nrecall@3 WITHOUT a department filter: %d of %d   (the question is searched in all departments)" % (h_no, len(QUERIES)))
    print("recall@3 WITH the department filter : %d of %d" % (h_yes, len(QUERIES)))
    return h_no, h_yes


def check():
    r = search("Who do I contact?", "billing", k=5)
    c1 = len(r) > 0 and all(d["department"] == "billing" for _, d in r)
    c2 = any(d["department"] != "billing" for _, d in search("Who do I contact?", None, k=5))
    h_yes, _ = recall(True)
    h_no, _ = recall(False)
    c3 = h_yes == len(QUERIES) and h_yes > h_no
    rows = [("with department='billing' every result is a billing document", c1),
            ("with NO department, all departments are still searched", c2),
            ("the filter lifts recall@3 to 12 of 12", c3)]
    print("")
    for i, (label, ok) in enumerate(rows, 1):
        print("CHECK %d  %-58s %s" % (i, label, "PASS" if ok else "FAIL"))
    print("")
    print("ALL CHECKS PASSED.  Now Part B: python app.py" if all(ok for _, ok in rows)
          else "Not yet - read the FAIL lines, fix, and run  python filter_lab.py --check  again.")


if __name__ == "__main__":
    check() if "--check" in sys.argv else show()
