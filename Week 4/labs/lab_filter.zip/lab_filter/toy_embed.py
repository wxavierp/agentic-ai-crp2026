"""
toy_embed.py - the STAND-IN embedding model used in the labs. Do not edit.

It is NOT a neural network. It turns a text into a list of numbers (a vector) in two steps:
  1. every word that belongs to a "meaning group" (refund, shipping, battery, ...) adds 1 to that group's slot
  2. every word also adds a little to one of 64 "spelling" slots
So two texts about the same meaning group get similar vectors - and two texts that mean the same
thing with DIFFERENT words (a word that is in no group) look unrelated. Real models (MiniLM,
text-embedding-3-small) learn this from data and are much better, but they fail in the same KINDS of ways.
"""
import re, zlib

STOP = set("a an the is are was were be been to of in on for and or it its my i me do does did can could how what when where "
           "which who whom with at by from this that there their your you we our if as will would should may might any some "
           "up out so than then them they he she his her us have has had get got".split())

GROUPS = {
    "RETURN":    "return returned returns returnable exchange swap send back",
    "MONEYBACK": "refund refunded refunds repaid credit",
    "SHIP":      "ship shipped shipping deliver delivery delivered courier dispatch dispatched parcel parcels",
    "TRACK":     "track tracking trace locate",
    "PAY":       "pay paid payment payments card cards invoice invoices bill billing charged charge statement",
    "BATTERY":   "battery charge charging power runtime",
    "BROKEN":    "broken damaged damage cracked defective faulty smashed",
    "WARRANTY":  "warranty guarantee covered covering coverage cover",
    "REPAIR":    "repair repairs fix fixed service technician technicians",
    "ACCOUNT":   "account login password username signin",
    "RESET":     "reset recover forgot forgotten restore",
    "PHONE":     "phone phones mobile smartphone handset",
    "LAPTOP":    "laptop laptops notebook",
    "HEADSET":   "headset headphones earbuds earphones",
    "TIME":      "days day hours hour week weeks business",
    "INTL":      "international overseas abroad customs duty duties",
    "CANCEL":    "cancel cancellation cancelled terminate",
    "SOFTWARE":  "software licence license activation key keys download",
    "GIFT":      "gift voucher vouchers coupon promo discount",
    "FREE":      "free",
}
NAMES = list(GROUPS)
WORD2G = {}
for i, (g, words) in enumerate(GROUPS.items()):
    for w in words.split():
        WORD2G.setdefault(w, []).append(i)
HASH = 64
DIM = len(NAMES) + HASH


def words(text):
    return [w for w in re.findall(r"[a-z0-9]+", text.lower().replace("-", " ")) if w not in STOP]


def embed(text):
    """text -> vector (list of DIM numbers)."""
    v = [0.0] * DIM
    for w in words(text):
        for g in WORD2G.get(w, []):
            v[g] += 1.0
        v[len(NAMES) + zlib.crc32(w.encode()) % HASH] += 0.35
    return [round(x, 3) for x in v]


def concepts(text):
    """Which meaning groups does this text touch? (to explain WHY two texts look alike)"""
    return sorted({NAMES[g] for w in words(text) for g in WORD2G.get(w, [])})
