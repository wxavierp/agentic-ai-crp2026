"""
LAB 3 - Part B: a search box in a browser, with Gradio.

First (once):       pip install gradio
Run it:             python app.py          (it prints a local address - open it)
Check your fix:     python app.py --check
Only edit the part marked  YOUR FIX.
"""
import sys
import gradio as gr
from filter_lab import search, DEPARTMENTS


def find(question, department):
    """What the app does when you press Submit: a question and a department in, a table of results out."""
    if not question.strip():
        return []
    results = search(question, department or None)
    return [["%.2f" % s, d["department"], d["text"]] for s, d in results]


# ============================================================================
#  YOUR FIX  - build the app.  Gradio needs three things:  a function, its inputs, its outputs.
#  A tiny example (a greeter):
#       gr.Interface(fn=greet, inputs=[gr.Textbox(label="Name"), gr.Checkbox(label="Shout")], outputs=gr.Textbox())
#  The inputs list matches the function's arguments IN ORDER.
# ============================================================================
demo = None
# YOUR FIX:  demo = gr.Interface(
#     fn=...,                                   # which function runs?
#     inputs=[ ...a Textbox for the question..., ...a Dropdown of DEPARTMENTS (add an empty "" choice = all)... ],
#     outputs=...,                              # gr.Dataframe(headers=["score", "department", "text"])
#     title="Support search",
# )


def check():
    ok1 = demo is not None and isinstance(demo, gr.Interface)
    kinds = [type(c).__name__ for c in demo.input_components] if ok1 else []
    ok2 = ok1 and kinds == ["Textbox", "Dropdown"]
    ok3 = ok1 and type(demo.output_components[0]).__name__ in ("Dataframe", "DataFrame")
    ok4 = ok1 and demo.fn is find
    rows = [("demo is a gr.Interface", ok1), ("inputs are a Textbox and a Dropdown, in that order", ok2),
            ("the output is a Dataframe", ok3), ("the function is find()", ok4)]
    print("")
    for i, (label, ok) in enumerate(rows, 1):
        print("CHECK %d  %-52s %s" % (i, label, "PASS" if ok else "FAIL"))
    print("")
    print("ALL CHECKS PASSED.  Run  python app.py  and try 3 questions with different departments." if all(o for _, o in rows)
          else "Not yet - read the FAIL lines, fix, and run  python app.py --check  again.")


if __name__ == "__main__":
    if "--check" in sys.argv:
        check()
    elif demo is None:
        sys.exit("demo is still None - fill in YOUR FIX first.")
    else:
        demo.launch()
