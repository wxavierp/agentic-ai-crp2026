"""gradio_util.py - tiny helpers so the four demos work on Gradio 4, 5 and 6.  (Students do NOT write Gradio tonight - it is
taught in Session 13. These apps are only the instructor's way of making each model call visible.)"""
import sys

try:
    import gradio as gr
except ImportError:                                    # the logic and the tests still work without it
    gr = None


def need_gradio():
    if gr is None:
        sys.exit("These demos are Gradio apps.  Install it once:   pip install gradio")


def chatbot(**kw):
    """A Chatbot that takes a list of {'role','content'} dicts, on any Gradio version."""
    try:
        return gr.Chatbot(type="messages", **kw)       # Gradio 4.4x / 5.x
    except TypeError:
        return gr.Chatbot(**kw)                        # Gradio 6: messages is the only format


def text_of(content):
    """A chat message's content as plain text (Gradio can hand over a string or a list of parts)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(text_of(p) for p in content)
    if isinstance(content, dict):
        return str(content.get("text", content.get("content", "")))
    return str(content or "")


def history_messages(history):
    """Gradio chat history -> [{'role','content'}] with plain-text content (user / assistant only)."""
    out = []
    for m in history or []:
        if isinstance(m, dict) and m.get("role") in ("user", "assistant"):
            out.append({"role": m["role"], "content": text_of(m.get("content"))})
    return out


def launch(demo, argv):
    port = 7860
    if "--port" in argv:
        port = int(argv[argv.index("--port") + 1])
    demo.launch(server_name="127.0.0.1", server_port=port, inbrowser="--no-browser" not in argv)
