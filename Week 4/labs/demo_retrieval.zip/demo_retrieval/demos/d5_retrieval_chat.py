"""
d5_retrieval_chat.py - AN AGENT THAT LOOKS IT UP FIRST.   (Session 13, demo 1: a Gradio app)

    python demos/d5_retrieval_chat.py              # real chat model from your .env + a real embedding model (EMBED_PROVIDER)
    python demos/d5_retrieval_chat.py --offline    # no key, no download: stand-in chat + stand-in embedder (for rehearsal only)
    python demos/d5_retrieval_chat.py --prefill    # the Lumo Audio knowledge text is already in the left box

LEFT: a large box. Paste the company's knowledge text here (or leave it empty).
RIGHT: the customer chat. Empty box = the agent has no documents and answers from the model alone.
With text in the box, every question first SEARCHES the text (embeddings), and only the best passages go to the model.
(Needs:  pip install gradio)
"""
import os, re, sys, zlib
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, ".."))
import gradio_util as G
from gradio_util import gr
import kit_rag

PERSONA = ("You are the customer support agent of Lumo Audio, an online headphone shop in the UAE. "
           "Answer the customer briefly and politely.")
FOUND = ("\n\nPASSAGES from the company's knowledge base:\n{passages}\n\n"
         "Answer ONLY from these passages and name the section you used. If they do not contain the answer, say you do not know.")
NOT_FOUND = ("\n\nThe company's knowledge base was searched and nothing matched this question. "
             "Say that you do not have that information and offer to pass the question to a human colleague.")
KB_FILE = os.path.join(HERE, "data", "lumo_knowledge.txt")


# ----------------------------------------------------------------------------- the knowledge text -> passages
def make_chunks(text):
    """Cut pasted text into passages: one per paragraph, each labelled 'Title > Section: paragraph'."""
    title = heading = None
    out = []
    for block in re.split(r"\n\s*\n", (text or "").strip()):
        body = []
        for ln in block.strip().split("\n"):
            if ln.startswith("# "):
                title = ln[2:].strip()
            elif ln.startswith("## "):
                heading = ln[3:].strip()
            elif ln.strip():
                body.append(ln.strip())
        if body:
            label = " > ".join(x for x in (title, heading) if x)
            out.append({"section": heading or title or "text", "text": (label + ": " if label else "") + " ".join(body)})
    return out


# ----------------------------------------------------------------------------- stand-ins (rehearsal only)
STOP = set("a an the do does did i my me we our you your is are was be to of in on for it its how what who when can could will would have has "
           "there this that and or if with at by from about any much many".split())


def toy_embed(texts):
    """NOT a model: a bag of words (no stop words, plural 's' removed) hashed to 256 numbers."""
    out = []
    for t in ([texts] if isinstance(texts, str) else texts):
        v = [0.0] * 256
        for w in re.findall(r"[a-z0-9]+", t.lower()):
            w = w[:-1] if w.endswith("s") and len(w) > 3 else w
            if w not in STOP:
                v[zlib.crc32(w.encode()) % 256] += 1.0
        out.append(v)
    return out


class OfflineChat:
    """NOT a model. Without passages it 'guesses'; with passages it quotes the best one. Lets you rehearse with no key."""
    provider, model = "offline", "stand-in"

    def chat(self, messages, tools=None, tool_choice="auto", temperature=0.0, max_tokens=300, model=None):
        class R:
            tool_calls = []
        r = R()
        system, q = messages[0]["content"], str(messages[-1]["content"]).lower()
        if "PASSAGES" in system:
            first = system.split("PASSAGES from the company's knowledge base:\n", 1)[1].split("\n", 1)[0]
            r.text = "From our knowledge base: " + re.sub(r"^\[\d\]\s*", "", first)
        elif "nothing matched" in system:
            r.text = "I'm sorry, I don't have that information. I can pass your question to a human colleague."
        else:
            r.text = "Returns are accepted within 30 days." if "return" in q else "Happy to help - could you tell me a little more?"
        return r


# ----------------------------------------------------------------------------- one customer message
class Agent:
    """Holds the chat model and the embedder; caches passage vectors so the same text is embedded only once."""

    def __init__(self, client, embed_fn):
        self.client, self.embed_fn, self._cache = client, embed_fn, {}

    def _vectors(self, texts):
        missing = [t for t in texts if t not in self._cache]
        if missing:
            for t, v in zip(missing, self.embed_fn(missing)):
                self._cache[t] = kit_rag._unit(v)
        return [self._cache[t] for t in texts]

    def retrieve(self, knowledge, question, k, min_score):
        chunks = make_chunks(knowledge)
        if not chunks:
            return chunks, []
        vecs = self._vectors([c["text"] for c in chunks])
        qv = kit_rag._unit(self.embed_fn([question])[0])
        ranked = sorted(((kit_rag.dot(qv, v), c) for v, c in zip(vecs, chunks)), key=lambda t: -t[0])[:int(k)]
        return chunks, [(round(s, 2), c) for s, c in ranked if s >= min_score]

    def answer(self, history, question, knowledge, persona, k=3, min_score=0.25):
        """-> (reply text, what was sent to the model, status line)"""
        chunks, hits = self.retrieve(knowledge, question, k, min_score)
        system = persona
        if not chunks:
            status = "No knowledge text: the agent answers from the model alone."
        elif hits:
            system += FOUND.format(passages="\n".join("[%d] %s" % (i, c["text"]) for i, (s, c) in enumerate(hits, 1)))
            status = "Looked up %d of %d passages: %s" % (len(hits), len(chunks), ", ".join("%s (%.2f)" % (c["section"], s) for s, c in hits))
        else:
            system += NOT_FOUND
            status = "Searched %d passages: nothing scored %.2f or more." % (len(chunks), min_score)
        messages = [{"role": "system", "content": system}] + list(history) + [{"role": "user", "content": question}]
        text = self.client.chat(messages, temperature=0.2, max_tokens=300).text or ""
        sent = "\n\n".join("[%s]\n%s" % (m["role"], m["content"]) for m in messages)
        return text.strip(), sent, status


# ----------------------------------------------------------------------------- the app
def build(client, label, embed_fn, embed_label, prefill=""):
    agent = Agent(client, embed_fn)

    def send(text, history, knowledge, persona, k, min_score):
        text = (text or "").strip()
        if not text:
            return history, "", gr.update(), gr.update()
        reply, sent, status = agent.answer(G.history_messages(history), text, knowledge, persona, k, min_score)
        history = list(history or []) + [{"role": "user", "content": text}, {"role": "assistant", "content": reply}]
        return history, "", "**" + status + "**", sent

    def clear():
        return [], "", "", ""

    with gr.Blocks(title="Customer support agent - looks it up first") as demo:
        gr.Markdown("## Customer support agent\nChat model: `%s` · embedding model: `%s`" % (label, embed_label))
        with gr.Row():
            with gr.Column(scale=1):
                knowledge = gr.Textbox(label="Knowledge - paste the company's documents here (empty = the agent has none)",
                                       lines=26, max_lines=26, value=prefill)
            with gr.Column(scale=1):
                chat = G.chatbot(label="Customer chat", height=430)
                msg = gr.Textbox(label="Customer message (press Enter)", autofocus=True)
                status = gr.Markdown()
                clear_btn = gr.Button("Clear the chat")
                with gr.Accordion("Exactly what was sent to the model in the last call", open=False):
                    sent_view = gr.Textbox(lines=12, interactive=False, show_label=False)
                with gr.Accordion("Agent instructions and search settings", open=False):
                    persona = gr.Textbox(label="Agent instructions", value=PERSONA, lines=3)
                    k = gr.Slider(1, 5, value=3, step=1, label="K - passages to look up")
                    min_score = gr.Slider(0, 0.9, value=0.25, step=0.05, label="Minimum score")
        outs = [chat, msg, status, sent_view]
        msg.submit(send, [msg, chat, knowledge, persona, k, min_score], outs, api_name="send")
        clear_btn.click(lambda: ([], "", "", ""), None, outs, api_name="clear")
    return demo


def pick(argv):
    if "--offline" in argv:
        return OfflineChat(), "OFFLINE stand-in (not a model)", toy_embed, "OFFLINE stand-in (not a model)"
    from utils.llm_client import LLMClient
    c = LLMClient()
    p, m = kit_rag.provider_and_model()
    return c, "%s/%s" % (c.provider, c._default_model()), kit_rag.embed, "%s/%s" % (p, m)


def main(argv):
    G.need_gradio()
    client, label, embed_fn, embed_label = pick(argv)
    prefill = open(KB_FILE, encoding="utf-8").read() if "--prefill" in argv else ""
    G.launch(build(client, label, embed_fn, embed_label, prefill), argv)


if __name__ == "__main__":
    main(sys.argv[1:])
