# Demo - an agent that looks it up first

A customer support agent for a made-up shop (Lumo Audio). Left: a big box for the company's knowledge. Right: the customer chat.
Empty box = the agent answers from the model alone. Text in the box = it searches the text first, and only the best passages go to the model.

## Run it
```
pip install gradio sentence-transformers openai python-dotenv
python demos/d5_retrieval_chat.py --offline      # no key, no download: stand-ins, to see the flow only
python demos/d5_retrieval_chat.py                # real: needs the .env below
```
`.env` (same folder as this README):
```
LLM_PROVIDER=openai        # or groq / ollama   (the chat model)
OPENAI_API_KEY=...         # the key for that provider
EMBED_PROVIDER=local       # local = sentence-transformers, free, no key (downloads a small model the first time)
```

## Try it
1. Leave the left box empty. Ask: *How many days do I have to return an item?* What does it do?
2. Paste `demos/data/lumo_knowledge.txt` into the left box (or start with `--prefill`). Ask the same question again.
3. Ask: *Who pays return shipping if I changed my mind?*, *Can I return Lumo Buds I opened yesterday?*, *Do you sell laptops?*
4. Open "Agent instructions and search settings": change K and the minimum score, and watch what changes.
5. Paste a knowledge text of your own project and ask it questions.

Read the line under the chat each time: it says which passages were looked up, and their scores.
