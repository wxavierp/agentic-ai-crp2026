"""
kit_rag.py - Session 13: give your agent a knowledge base.

  embed(texts)              turn texts into vectors with a REAL embedding model (a package function)
  chunk_words / chunk_by_headings / load_documents     cut your documents into chunks
  Index                     add_documents -> search (with a metadata filter) -> save / load
  rag_tools(index)          the search as a TOOL your agent can call, answers carry their source
  eval_retrieval(index, tasks)   recall@K on golden retrieval tasks (question + expected source + expected phrase)

Pick the embedding model with .env (or environment):
  EMBED_PROVIDER=local    (default)  sentence-transformers, runs on your laptop, free, no key.   pip install sentence-transformers
  EMBED_PROVIDER=openai              text-embedding-3-small, needs OPENAI_API_KEY.              pip install openai
  EMBED_PROVIDER=ollama              nomic-embed-text through a local Ollama.                   pip install openai
  EMBED_PROVIDER=hash                a word-hash stand-in for offline tests ONLY - it is not a model.
RULE: the SAME model must embed the documents and the questions. An index remembers its model and refuses to mix.
"""
import json, math, os, re, zlib

DEFAULT_MODELS = {"local": "all-MiniLM-L6-v2", "openai": "text-embedding-3-small", "ollama": "nomic-embed-text", "hash": "hash-256"}
_local_cache = {}


# ----------------------------------------------------------------------------- 1. embedding
def provider_and_model(provider=None, model=None):
    provider = (provider or os.getenv("EMBED_PROVIDER", "local")).lower()
    if provider not in DEFAULT_MODELS:
        raise ValueError("EMBED_PROVIDER must be one of: " + ", ".join(DEFAULT_MODELS))
    return provider, model or os.getenv("EMBED_MODEL") or DEFAULT_MODELS[provider]


def embed(texts, provider=None, model=None):
    """list of texts (or one text) -> list of vectors (lists of floats)."""
    if isinstance(texts, str):
        texts = [texts]
    texts = list(texts)
    provider, model = provider_and_model(provider, model)
    if provider == "local":
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            raise SystemExit("Install the local embedding model once:  pip install sentence-transformers")
        if model not in _local_cache:
            _local_cache[model] = SentenceTransformer(model)          # downloads once, then cached
        return [[float(x) for x in v] for v in _local_cache[model].encode(texts)]
    if provider in ("openai", "ollama"):
        from openai import OpenAI
        client = OpenAI() if provider == "openai" else OpenAI(base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1"), api_key="ollama")
        out = []
        for i in range(0, len(texts), 96):                             # batches
            out += [d.embedding for d in client.embeddings.create(model=model, input=texts[i:i + 96]).data]
        return out
    # hash: lexical stand-in, deterministic, for tests only
    vecs = []
    for t in texts:
        v = [0.0] * 256
        for w in re.findall(r"[a-z0-9]+", t.lower()):
            v[zlib.crc32(w.encode()) % 256] += 1.0
        vecs.append(v)
    return vecs


def _unit(v):
    n = math.sqrt(sum(x * x for x in v))
    return [x / n for x in v] if n else v


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


# ----------------------------------------------------------------------------- 2. documents and chunks
def load_documents(folder, extensions=(".md", ".txt")):
    """every .md/.txt file in folder -> [{"source": filename, "title": first '# ' line or filename, "text": ...}]"""
    docs = []
    for fn in sorted(os.listdir(folder)):
        if fn.lower().endswith(extensions):
            text = open(os.path.join(folder, fn), encoding="utf-8").read()
            first = text.strip().split("\n")[0]
            docs.append({"source": fn, "title": first[2:].strip() if first.startswith("# ") else fn, "text": text})
    return docs


def chunk_words(text, size=200, overlap=30):
    """pieces of `size` words; neighbours share `overlap` words."""
    if overlap >= size:
        raise ValueError("overlap must be smaller than size")
    words, step, out = text.split(), size - overlap, []
    for start in range(0, len(words), step):
        out.append(" ".join(words[start:start + size]))
        if start + size >= len(words):
            break
    return out


def chunk_by_headings(title, text):
    """one chunk per paragraph, labelled 'Title > Section: paragraph'.  Returns [(section, chunk_text), ...]"""
    out = []
    for section in re.split(r"^#{2,3} ", text, flags=re.M)[1:]:
        heading, _, body = section.partition("\n")
        for para in [p.strip() for p in body.split("\n\n") if p.strip()]:
            out.append((heading.strip(), "%s > %s: %s" % (title, heading.strip(), para)))
    return out


# ----------------------------------------------------------------------------- 3. the index
class Index:
    def __init__(self, provider=None, model=None):
        self.provider, self.model = provider_and_model(provider, model)
        self.items = []            # [{"text", "source", "section", "metadata", "vector"}]

    def add_documents(self, docs, chunking="headings", size=200, overlap=30, metadata=None):
        """docs from load_documents().  chunking = "headings" (recommended for structured docs) or "words".
        metadata = extra fields kept on every chunk, e.g. {"department": "billing"}; or a function(doc) -> dict."""
        new = []
        for d in docs:
            extra = metadata(d) if callable(metadata) else dict(metadata or {})
            if chunking == "headings":
                pieces = chunk_by_headings(d["title"], d["text"]) or [("", d["text"])]
            else:
                pieces = [("", c) for c in chunk_words(d["text"], size, overlap)]
            for section, text in pieces:
                new.append({"text": text, "source": d["source"], "section": section, "metadata": extra})
        vectors = embed([n["text"] for n in new], self.provider, self.model)          # <- the real model runs here
        for n, v in zip(new, vectors):
            n["vector"] = _unit(v)
        self.items += new
        return len(new)

    def search(self, query, k=3, where=None, min_score=0.0):
        """the k best chunks.  where = {"department": "billing"} keeps only chunks whose metadata matches (BEFORE ranking)."""
        qv = _unit(embed([query], self.provider, self.model)[0])
        pool = [it for it in self.items if all(it["metadata"].get(f) == v for f, v in (where or {}).items())]
        ranked = sorted(((dot(qv, it["vector"]), it) for it in pool), key=lambda t: -t[0])[:k]
        return [dict(score=round(s, 3), text=it["text"], source=it["source"], section=it["section"], metadata=it["metadata"])
                for s, it in ranked if s >= min_score]

    def save(self, path="index.json"):
        json.dump({"provider": self.provider, "model": self.model, "items": self.items}, open(path, "w"))

    @classmethod
    def load(cls, path="index.json", provider=None, model=None):
        data = json.load(open(path))
        idx = cls(provider or data["provider"], model or data["model"])
        if (idx.provider, idx.model) != (data["provider"], data["model"]):
            raise ValueError("This index was built with %s/%s but you are asking with %s/%s. Never mix embedding models - rebuild the index."
                             % (data["provider"], data["model"], idx.provider, idx.model))
        idx.items = data["items"]
        return idx


# ----------------------------------------------------------------------------- 4. the agent tool
SEARCH_SCHEMA = {"type": "function", "function": {
    "name": "search_knowledge",
    "description": "Search the knowledge base. Use it BEFORE answering a question about policies, products or procedures. "
                   "Answer only from what it returns and name the source. If it says NO_MATCH, say you do not know.",
    "parameters": {"type": "object", "properties": {
        "query": {"type": "string", "description": "what to look for, in plain words"},
        "department": {"type": "string", "description": "optional: only search this department"}},
        "required": ["query"]}}}


def rag_tools(index, k=3, min_score=0.25, department_field="department"):
    """-> [(function, schema)] ready for agent.register(fn, schema)."""
    def search_knowledge(query, department=None):
        where = {department_field: department} if department else None
        hits = index.search(query, k=k, where=where, min_score=min_score)
        if not hits:
            return "NO_MATCH: nothing in the knowledge base is close enough to this question."
        return "\n".join("[%d] (source: %s, score %.2f) %s" % (i, h["source"], h["score"], h["text"]) for i, h in enumerate(hits, 1))
    return [(search_knowledge, SEARCH_SCHEMA)]


# ----------------------------------------------------------------------------- 5. golden retrieval tasks
def eval_retrieval(index, tasks, k=3, min_score=0.0, quiet=False):
    """tasks = [{"id", "question", "expected_source", "expected_phrase", "where": optional}]
    A task PASSES when one of the top-k chunks comes from expected_source AND contains expected_phrase."""
    rows = []
    for t in tasks:
        hits = index.search(t["question"], k=k, where=t.get("where"), min_score=min_score)
        rank = next((i for i, h in enumerate(hits, 1)
                     if h["source"] == t["expected_source"] and t["expected_phrase"].lower() in h["text"].lower()), None)
        rows.append({"id": t["id"], "question": t["question"], "expected_source": t["expected_source"], "rank": rank,
                     "pass": rank is not None, "top_source": hits[0]["source"] if hits else None})
    recall = sum(r["pass"] for r in rows) / len(rows) if rows else 0.0
    if not quiet:
        print("%-5s %-6s %-5s %s" % ("task", "result", "rank", "question  (expected source / what came first)"))
        for r in rows:
            print("%-5s %-6s %-5s %s   [%s / %s]" % (r["id"], "PASS" if r["pass"] else "FAIL", r["rank"] or "-", r["question"][:48],
                                                  r["expected_source"], r["top_source"]))
        print("\nrecall@%d = %d of %d = %.0f%%" % (k, sum(r["pass"] for r in rows), len(rows), 100 * recall))
    return {"recall": recall, "k": k, "rows": rows}


def embedding_report(sentences, provider=None, model=None):
    """prints the dimension and the similarity of the first sentence to each of the others - a 30-second sanity check."""
    vecs = [_unit(v) for v in embed(sentences, provider, model)]
    p, m = provider_and_model(provider, model)
    print("model: %s/%s   numbers per vector: %d" % (p, m, len(vecs[0])))
    for s, v in zip(sentences[1:], vecs[1:]):
        print("  %.2f  %s" % (dot(vecs[0], v), s))
