# Lab 1 - Search, and which embedding model?  (30 minutes)

**You will be able to:** find the closest documents to a question with cosine similarity (using a built-in, not a hand-written formula), set a minimum score, and compare embedding models on the same questions to choose one.

Part A needs only Python 3 and numpy (`pip install numpy` if it is missing). Part B uses real models: `pip install sentence-transformers` (you started it at the beginning of the session).
Check that Python works: `python search.py` (if `python` is not found, try `python3`).

> **About Part A's "model".** The documents (`corpus.json`) are already turned into vectors by a **stand-in** (`toy_embed.py`).
> It is *not* a neural network, but it fails in the same *kinds* of ways real embedding models do.
> In Part B you use **real models**.

## Part A - fix the search (12 min)

### 1. Run it (2 min)
```
python search.py
```
You see 10 questions. For each one: the 3 closest documents, their score, and `<- right answer` if the right one is there.
Right now every line says `WRONG`, and the documents that win are the long catch-all ones (G1, G2, G3).

### 2. Write one sentence (1 min)
**What is wrong with the results, and what do you think the score is rewarding?**

### 3. Fix it (7 min)
Open `search.py`. Edit only the places marked `YOUR FIX`:
1. `similarity()` - it is a plain dot product. Make it **cosine similarity**, with a **built-in**: numpy, scikit-learn or `sentence_transformers.util.cos_sim`. Do not write the formula by hand.
2. `MIN_SCORE` - *"What is the capital of France?"* has no answer in this knowledge base, but you still get 3 results. Choose a score below which nothing is returned (try `0.3`).
3. `is_hit()` - say when the right document is among the results (**recall@3**).

### 4. Verify (2 min)
```
python search.py --check
```
**Verify that all 3 checks pass.** Some queries are still WRONG: that is expected. (`python search.py --why 5` shows why.)

## Part B - which embedding model? (15 min)

### 5. Run the comparison (4 min)
```
python compare_models.py
```
The same documents and questions go through two **real** embedding models. For each: how many numbers per vector, how long it took, recall@3 (with *your* search from Part A), and the scores of the right answers against the best score of the out-of-scope question.
No install yet? `python compare_models.py --offline` runs two stand-ins so you can see the table.
A model that cannot load says `SKIPPED` and why - read it.

### 6. Add a third model (5 min)
In `compare_models.py`, at `YOUR FIX 1`, add one more model to `MODELS`: the multilingual local one, OpenAI `text-embedding-3-small` (needs a key) or Ollama `nomic-embed-text`. Run again.

### 7. Make your decision (4 min)
At `YOUR FIX 2`, set `MY_PICK` (the model's `name`) and `MY_REASON` (at least 15 words). Use the numbers **and** at least two of: cost, privacy, language, size, speed.
```
python compare_models.py --check
```

### 8. Write one sentence (2 min)
**What did I learn?** In particular: is your `MIN_SCORE = 0.3` right for every model in the table? Why not?

## Stretch
* `python embed_it.py` - embed three sentences with a real model in three lines.
* `python search.py --real` - the Part A search with a real model.
* `python which_endpoint.py` (OpenAI key) - ask the embeddings endpoint for a vector from a **chat** model, and write down what happens.

## Keep it
Keep `search.py` and `compare_models.py` as they are, with your decision. In the last block you use the model you chose, on your own documents.
