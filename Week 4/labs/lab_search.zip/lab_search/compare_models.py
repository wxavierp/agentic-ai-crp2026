"""
LAB 1, PART B - Which embedding model?   Same documents, same questions, different models.

Run it:        python compare_models.py            (needs: pip install sentence-transformers  - the first run downloads the models)
No install:    python compare_models.py --offline  (two stand-ins; shows how the script works)
Check:         python compare_models.py --check    (add --offline if you are using the stand-ins)

It uses YOUR similarity(), MIN_SCORE and is_hit() from search.py - fix Part A first.
Edit only the places marked  YOUR FIX.
"""
import json, os, sys, time
import search
from search import DOCS, QUERIES
import toy_embed

# ============================================================================
#  YOUR FIX 1 - add a THIRD model to this list
# ============================================================================
MODELS = [
    {"name": "MiniLM", "provider": "local", "model": "all-MiniLM-L6-v2", "note": "local, free, small"},
    {"name": "bge-small", "provider": "local", "model": "BAAI/bge-small-en-v1.5", "note": "local, free, small"},
    # YOUR FIX 1: add one more.  Pick ONE (copy the shape of the lines above):
    #   local, free, understands many languages:  provider "local",  model "paraphrase-multilingual-MiniLM-L12-v2"
    #   OpenAI (needs OPENAI_API_KEY, tiny cost):  provider "openai", model "text-embedding-3-small"
    #   Ollama (needs Ollama running):             provider "ollama", model "nomic-embed-text"
]

# ============================================================================
#  YOUR FIX 2 - your decision (after you have run it)
# ============================================================================
MY_PICK = None          # YOUR FIX 2: the "name" of the model you would use for a support agent, e.g. "MiniLM"
MY_REASON = ""          # YOUR FIX 2: at least 15 words. Use the numbers in the table AND at least two of: cost, privacy, language, size, speed.


# ============================================================================
#  THE COMPARISON  (do not edit)
# ============================================================================
def word_hash(texts):
    import re, zlib
    out = []
    for t in texts:
        v = [0.0] * 256
        for w in re.findall(r"[a-z0-9]+", t.lower()):
            v[zlib.crc32(w.encode()) % 256] += 1.0
        out.append(v)
    return out


OFFLINE_MODELS = [
    {"name": "stand-in A", "fn": lambda texts: [toy_embed.embed(t) for t in texts], "note": "toy_embed.py"},
    {"name": "stand-in B", "fn": word_hash, "note": "word hash"},
]


def embed_with(m, texts):
    """texts -> vectors, with ONE package call per provider."""
    if m.get("fn"):
        return m["fn"](texts)
    if m["provider"] == "local":
        from sentence_transformers import SentenceTransformer           # downloads the model the first time
        return SentenceTransformer(m["model"]).encode(texts).tolist()
    from openai import OpenAI                                           # openai and ollama speak the same API
    client = OpenAI() if m["provider"] == "openai" else OpenAI(base_url="http://localhost:11434/v1", api_key="ollama")
    return [d.embedding for d in client.embeddings.create(model=m["model"], input=texts).data]


def run_model(m):
    t0 = time.time()
    try:
        docs_v = embed_with(m, [d["text"] for d in DOCS])
        qs_v = embed_with(m, [q["query"] for q in QUERIES])
    except BaseException as e:               # missing package, no key, no network, model not found ...
        msg = str(e).strip().splitlines()
        return {"name": m["name"], "error": (msg[-1] if msg else type(e).__name__)[:110]}
    secs = time.time() - t0
    docs = [dict(d, vector=v) for d, v in zip(DOCS, docs_v)]
    right, wrong, right_scores, none_best = 0, [], [], None
    for n, (q, qv) in enumerate(zip(QUERIES, qs_v), 1):
        res = search.search(qv, docs)
        ok = search.is_hit(res, q["expected"])
        right += bool(ok)
        if not ok:
            wrong.append(n)
        if q["expected"]:
            exp = next(d for d in docs if d["id"] == q["expected"])
            right_scores.append(search.similarity(qv, exp["vector"]))
        else:
            none_best = max(search.similarity(qv, d["vector"]) for d in docs)
    return {"name": m["name"], "dims": len(docs_v[0]), "secs": secs, "recall": right, "wrong": wrong,
            "lo": min(right_scores), "hi": max(right_scores), "none_best": none_best}


def compare(models):
    results = [run_model(m) for m in models]
    print("%-12s %7s %7s %9s  %-22s %s" % ("model", "numbers", "seconds", "recall@3", "right-answer scores", "best score of the out-of-scope question"))
    for r in results:
        if "error" in r:
            print("%-12s  SKIPPED: %s" % (r["name"], r["error"]))
        else:
            print("%-12s %7d %7.1f %6d/%-2d  %.2f to %.2f           %.2f   (your MIN_SCORE is %.2f)"
                  % (r["name"], r["dims"], r["secs"], r["recall"], len(QUERIES), r["lo"], r["hi"], r["none_best"], search.MIN_SCORE))
    for r in results:
        if "error" not in r and r["wrong"]:
            print("  %s still wrong on queries %s" % (r["name"], r["wrong"]))
    print("\nLook at the last column. A MIN_SCORE that is right for one model can be wrong for another:")
    print("the floor must sit ABOVE the out-of-scope score and BELOW the right-answer scores - for each model.")
    return results


def check(models):
    results = [run_model(m) for m in models]
    ran = [r for r in results if "error" not in r]
    names = [m["name"] for m in models + MODELS + OFFLINE_MODELS]
    words = len((MY_REASON or "").split())
    rows = [("MODELS has at least 3 models (you added one)", len(models) >= 3),
            ("at least 2 models ran and gave results", len(ran) >= 2),
            ("MY_PICK is the name of one of the models", MY_PICK in names),
            ("MY_REASON has at least 15 words", words >= 15)]
    print("")
    for i, (label, ok) in enumerate(rows, 1):
        print("CHECK %d  %-52s %s" % (i, label, "PASS" if ok else "FAIL"))
    print("")
    if all(ok for _, ok in rows):
        print("ALL CHECKS PASSED.  Last question: which embedding model will YOUR project use - and what would make you change it?")
    else:
        print("Not yet - read the FAIL lines, fix, and run  python compare_models.py --check  again.")


if __name__ == "__main__":
    offline = "--offline" in sys.argv
    models = (OFFLINE_MODELS + MODELS[2:]) if offline else MODELS
    check(models) if "--check" in sys.argv else compare(models)
