"""
Optional - needs an OpenAI key (OPENAI_API_KEY in your .env or environment) and:  pip install openai
Embedding models and chat models are DIFFERENT families.  Ask the embeddings endpoint for both and write down what happens.
"""
import os
from openai import OpenAI

client = OpenAI()
for name in ("gpt-4o-mini", "text-embedding-3-small"):
    try:
        r = client.embeddings.create(model=name, input="How do I get my money back?")
        print("%-24s -> a vector of %d numbers" % (name, len(r.data[0].embedding)))
    except Exception as e:
        print("%-24s -> ERROR: %s" % (name, str(e)[:160]))
