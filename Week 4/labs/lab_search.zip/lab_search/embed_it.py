"""
Optional (stretch) - embed with a REAL model yourself.   python embed_it.py

First (once):   pip install sentence-transformers      (a few minutes; it downloads a small model on first run)
Then fill in the three lines marked YOUR TURN.
"""
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")      # a small embedding model that runs on your laptop

sentences = [
    "How do I get my money back?",
    "Refunds go back to the original payment card within 5 business days.",
    "The headset battery lasts about 20 hours.",
]

# YOUR TURN 1: turn the three sentences into vectors with ONE call:  model.encode(...)
vectors = None

# YOUR TURN 2: print how many numbers one vector has  (len(...)).   Expect 384.
print("numbers per vector:", None)

# YOUR TURN 3: cosine similarity of sentence 0 with sentence 1, and of sentence 0 with sentence 2.
#   shortcut: from sentence_transformers import util;  util.cos_sim(vectors[0], vectors[1])
print("money-back vs refund :", None)
print("money-back vs battery:", None)

# Then answer in one sentence: did the real model understand that "money back" means "refund"?
# (The stand-in in search.py could not - that was query 5.)
