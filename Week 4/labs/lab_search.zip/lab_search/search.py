"""
LAB 1 - Nearest neighbours by hand.

Run the search:            python search.py
Check your fixes:          python search.py --check
Why did query 5 go wrong?  python search.py --why 5
(optional) real model:     python search.py --real      (needs: pip install sentence-transformers)
Part B (which model?):     python compare_models.py

The "model" here is a STAND-IN (toy_embed.py, not a neural network). The documents are already turned
into vectors (corpus.json). Only edit the parts marked  YOUR FIX.
"""
import json, math, os, sys
from toy_embed import embed, concepts

HERE = os.path.dirname(os.path.abspath(__file__))
DOCS = json.load(open(os.path.join(HERE, "corpus.json")))
QUERIES = json.load(open(os.path.join(HERE, "queries.json")))
K = 3

# ============================================================================
#  YOUR FIX  - the search
# ============================================================================
MIN_SCORE = 0.0          # YOUR FIX 2: below this score a document is "not a match". Try 0.3.


def similarity(a, b):
    """How alike are two vectors? Higher = more alike."""
    # YOUR FIX 1: this is a plain dot product.  Make it COSINE similarity.  Do NOT hand-write the formula - use a built-in:
    #     numpy:     np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))        (import numpy as np)
    #     sklearn:   cosine_similarity([a], [b])[0][0]                             (from sklearn.metrics.pairwise import ...)
    #     sentence_transformers.util.cos_sim(a, b)
    #   A vector of all zeros must give 0.0, not an error.
    return sum(x * y for x, y in zip(a, b))


def is_hit(results, expected_id):
    """Did the right document come back among the results?  results = [(score, doc), ...]"""
    # YOUR FIX 3: return True when expected_id is the id of one of the documents in results.
    #   For a query with NO right answer (expected_id is None): True when results is empty.
    return False


# ============================================================================
#  THE SEARCH  (do not edit)
# ============================================================================
def search(query_vec, docs=DOCS, k=K):
    scored = sorted(((similarity(query_vec, d["vector"]), d) for d in docs), key=lambda t: t[0], reverse=True)
    return [(s, d) for s, d in scored[:k] if s >= MIN_SCORE]


def show(embed_fn=embed, docs=DOCS):
    right = 0
    wrong = []
    for n, q in enumerate(QUERIES, 1):
        res = search(embed_fn(q["query"]), docs)
        ok = is_hit(res, q["expected"])
        right += bool(ok)
        if not ok:
            wrong.append(n)
        print("%2d  %-4s %s" % (n, "OK" if ok else "WRONG", q["query"]))
        for s, d in res:
            mark = "  <- right answer" if d["id"] == q["expected"] else ""
            print("        %.2f  %-3s %s%s" % (s, d["id"], d["text"][:70], mark))
        if not res:
            print("        (nothing found)")
    print("\nrecall@%d: %d of %d queries have the right document in the results" % (K, right, len(QUERIES)))
    if wrong:
        print("Wrong queries: %s    -> try:  python search.py --why %d" % (wrong, wrong[0]))
    return right, wrong


def why(n):
    q = QUERIES[n - 1]
    res = search(embed(q["query"]), DOCS, k=1)
    print("Query %d: %s" % (n, q["query"]))
    print("  meaning groups it touches : %s" % (concepts(q["query"]) or "(none)"))
    if res:
        print("  top result %-3s           : %s" % (res[0][1]["id"], concepts(res[0][1]["text"])))
    if q["expected"]:
        exp = next(d for d in DOCS if d["id"] == q["expected"])
        print("  right answer %-3s         : %s" % (exp["id"], concepts(exp["text"])))
        print("  right answer text         : %s" % exp["text"])
    print("  Ask: what does the query share with the top result - and with the right answer?")


def check():
    a = [1.0, 2.0, 3.0]
    c1 = (abs(similarity(a, [2.0, 4.0, 6.0]) - 1.0) < 1e-6 and abs(similarity([1, 0], [0, 1])) < 1e-6
          and similarity([0, 0], [1, 1]) == 0)
    far = search(embed("What is the capital of France?"))
    c2 = far == []
    right, wrong = show_quiet()
    c3 = right >= 6
    rows = [("similarity() is cosine (a vs 2a = 1, unrelated = 0, zeros = 0)", c1),
            ("a question the KB cannot answer returns NOTHING", c2),
            ("is_hit() works and recall@3 is at least 6 of 10", c3)]
    print("")
    for i, (label, ok) in enumerate(rows, 1):
        print("CHECK %d  %-58s %s" % (i, label, "PASS" if ok else "FAIL"))
    print("")
    if all(ok for _, ok in rows):
        print("ALL CHECKS PASSED.  Part B next:  python compare_models.py   (and: which queries are still wrong?  python search.py --why N)")
    else:
        print("Not yet - read the FAIL lines, fix, and run  python search.py --check  again.")


def show_quiet():
    right, wrong = 0, []
    for n, q in enumerate(QUERIES, 1):
        ok = is_hit(search(embed(q["query"])), q["expected"])
        right += bool(ok)
        if not ok:
            wrong.append(n)
    return right, wrong


def real_embed_fn():
    from sentence_transformers import SentenceTransformer       # the package function students use in the project
    model = SentenceTransformer("all-MiniLM-L6-v2")
    return model, (lambda text: model.encode(text).tolist())


if __name__ == "__main__":
    if "--check" in sys.argv:
        check()
    elif "--why" in sys.argv:
        why(int(sys.argv[sys.argv.index("--why") + 1]))
    elif "--real" in sys.argv:
        try:
            model, fn = real_embed_fn()
        except ImportError:
            sys.exit("Install it first:  pip install sentence-transformers   (the first run downloads a small model)")
        docs = [dict(d, vector=fn(d["text"])) for d in DOCS]
        print("Real model: vectors have %d numbers each (the stand-in had %d).\n" % (len(docs[0]["vector"]), len(DOCS[0]["vector"])))
        show(fn, docs)
    else:
        show()
