"""
LAB 2 - Chunking experiment.

Run the 3 configs:       python run.py
Check your fixes:        python run.py --check   (saves results.json)
Look at one question:    python run.py --show B6
(optional) real model:   python run.py --real        (needs: pip install sentence-transformers)

The corpus (corpus/, 40 product pages) and the 20 questions (questions.json) are ready.
The "model" is the same STAND-IN as Lab 1.  Sizes are counted in WORDS (to keep the pages short).
Only edit the parts marked  YOUR FIX.
"""
import json, math, os, re, sys
from toy_embed import embed as stand_in_embed

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "corpus")
QUESTIONS = json.load(open(os.path.join(HERE, "questions.json")))
K = 3
CONFIGS = [  # name, how to split
    ("small",     "fixed", dict(size=60,  overlap=9)),
    ("medium",    "fixed", dict(size=120, overlap=15)),
    ("structure", "headings", {}),
]

# ============================================================================
#  YOUR FIX  - the chunkers and your recommendation
# ============================================================================
def chunk_fixed(text, size, overlap):
    """Cut the text into pieces of `size` words. Neighbouring pieces must SHARE `overlap` words."""
    words = text.split()
    step = size                      # YOUR FIX 1: how far to move forward each time?  (hint: size minus the overlap)
    chunks = []
    for start in range(0, len(words), step):
        chunks.append(" ".join(words[start:start + size]))
        if start + size >= len(words):
            break
    return chunks


def chunk_by_headings(title, text):
    """One chunk per paragraph, and each chunk remembers WHERE it came from."""
    chunks = []
    for section in re.split(r"^## ", text, flags=re.M)[1:]:
        heading, _, body = section.partition("\n")
        for paragraph in [p.strip() for p in body.split("\n\n") if p.strip()]:
            chunk = paragraph        # YOUR FIX 2: put the page title and the section name in front:   Title > Section: paragraph
            chunks.append(chunk)
    return chunks


# YOUR FIX 3 - after you have read the table and the failures, make your recommendation:
MY_PICK = None       # "small", "medium" or "structure"
MY_REASON = ""       # one sentence (at least 12 words): why this config, and which questions it still misses


# ============================================================================
#  THE EXPERIMENT  (do not edit)
# ============================================================================
def is_hit(top_chunks, question):
    """top_chunks = [(file, chunk_text), ...] the search returned. Is the answer in one of them - from the RIGHT page?"""
    return any(fn == question["file"] and question["answer"] in text for fn, text in top_chunks)


def cosine(a, b):
    d = sum(x * y for x, y in zip(a, b))
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(x * x for x in b))
    return d / (na * nb) if na and nb else 0.0


def build_chunks(kind, params):
    out = []
    for fn in sorted(os.listdir(CORPUS)):
        text = open(os.path.join(CORPUS, fn)).read()
        title = text.split("\n")[0][2:]
        pieces = chunk_fixed(text, **params) if kind == "fixed" else chunk_by_headings(title, text)
        out += [(fn, p) for p in pieces]
    return out


def run_config(kind, params, embed_fn, only=None):
    chunks = build_chunks(kind, params)
    vectors = embed_fn([c[1] for c in chunks])
    hits, failed, tops = 0, [], {}
    for q in QUESTIONS:
        if only and q["id"] != only:
            continue
        qv = embed_fn([q["question"]])[0]
        order = sorted(range(len(chunks)), key=lambda i: -cosine(qv, vectors[i]))[:K]
        top = [chunks[i] for i in order]
        tops[q["id"]] = top
        if is_hit(top, q):
            hits += 1
        else:
            failed.append(q["id"])
    return len(chunks), hits, failed, tops


def stand_in(texts):
    return [stand_in_embed(t) for t in texts]


def real_embed():
    from sentence_transformers import SentenceTransformer         # the package function you use in your project
    model = SentenceTransformer("all-MiniLM-L6-v2")
    return lambda texts: model.encode(list(texts)).tolist()


def table(embed_fn, save=False):
    print("%-10s %-22s %7s %12s   %s" % ("config", "setting", "chunks", "recall@%d" % K, "questions it missed"))
    results = {}
    for name, kind, params in CONFIGS:
        n, hits, failed, _ = run_config(kind, params, embed_fn)
        results[name] = {"chunks": n, "hits": hits, "of": len(QUESTIONS), "missed": failed}
        setting = ("%d words, overlap %d" % (params["size"], params["overlap"])) if kind == "fixed" else "per heading"
        print("%-10s %-22s %7d %9d/%d   %s" % (name, setting, n, hits, len(QUESTIONS), " ".join(failed) or "-"))
    if save:
        json.dump(results, open(os.path.join(HERE, "results.json"), "w"), indent=1)
    return results


def show(qid, embed_fn):
    q = next(x for x in QUESTIONS if x["id"] == qid)
    print("Question %s (%s): %s" % (qid, q["type"], q["question"]))
    print("Right page: %s     Answer: %s\n" % (q["file"], q["answer"]))
    for name, kind, params in CONFIGS:
        _, _, _, tops = run_config(kind, params, embed_fn, only=qid)
        print("--- %s: top %d chunks" % (name, K))
        for fn, c in tops[qid]:
            print("   %s %-26s %s" % ("*" if fn == q["file"] and q["answer"] in c else " ", fn[:26], c[:95].replace("\n", " ")))
        print("")
    print("(* = the chunk that holds the answer)")


def check():
    t = " ".join("w%d" % i for i in range(100))
    ch = chunk_fixed(t, 60, 9)
    c1 = len(ch) >= 2 and ch[0].split()[-9:] == ch[1].split()[:9]
    sample = "# Falcon X2 laptop\n\n## Setup\n\nPlug it in.\n"
    hs = chunk_by_headings("Falcon X2 laptop", sample)
    c2 = len(hs) == 1 and hs[0].startswith("Falcon X2 laptop > Setup:") and "Plug it in." in hs[0]
    res = table(stand_in, save=False)
    best = max(res, key=lambda n: res[n]["hits"])
    c3 = res["structure"]["hits"] >= 15 and best == "structure"
    c4 = res["small"]["hits"] > 6
    c5 = MY_PICK in res and MY_PICK == best and len(MY_REASON.split()) >= 12
    json.dump(dict(results=res, pick=MY_PICK, reason=MY_REASON), open(os.path.join(HERE, "results.json"), "w"), indent=1)
    rows = [("neighbouring chunks share the overlap words", c1),
            ("a structure chunk starts with 'Title > Section:'", c2),
            ("structure-aware reaches 15 of 20 and is the best config", c3),
            ("small (with its overlap) now beats its old score of 3", c4),
            ("MY_PICK is the best config and MY_REASON is a real sentence", c5)]
    print("")
    for i, (label, ok) in enumerate(rows, 1):
        print("CHECK %d  %-52s %s" % (i, label, "PASS" if ok else "FAIL"))
    print("")
    print("ALL CHECKS PASSED.  results.json saved.  Now read the failures: python run.py --show <id>" if all(ok for _, ok in rows)
          else "Not yet - read the FAIL lines, fix, and run  python run.py --check  again.")


if __name__ == "__main__":
    fn = stand_in
    if "--real" in sys.argv:
        try:
            fn = real_embed()
        except ImportError:
            sys.exit("Install it first:  pip install sentence-transformers")
        print("(real model: all-MiniLM-L6-v2)\n")
    if "--check" in sys.argv:
        check()
    elif "--show" in sys.argv:
        show(sys.argv[sys.argv.index("--show") + 1], fn)
    else:
        table(fn)
