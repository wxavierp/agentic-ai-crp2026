# Lab 2 - Chunking experiment  (30 minutes)

**You will be able to:** cut documents into chunks three different ways, measure each with **recall@3**, and recommend a config with evidence.

You need only Python 3 and this folder. No key, no installs for the main part.
Check that Python works: `python run.py`.

**What is here:** `corpus/` = 40 product pages (a title, then `##` sections). `questions.json` = 20 questions, each with the page and the exact words that answer it.
**recall@3** = for how many of the 20 questions is the answer inside the top 3 chunks the search returns?
(Sizes are counted in *words* so the pages stay short. Real systems count *tokens*, about 1.3 per word.)

## 1. Run it (3 min)
```
python run.py
```
You see three configs: **small** (60 words, 9 shared with the next chunk), **medium** (120 words, 15 shared), **structure** (one chunk per paragraph, split on the `##` headings).
Look at the *chunks* column and at which questions each config missed.

## 2. Look at failures (5 min)
Look at what the search returned for one missed question of each kind:
```
python run.py --show A1      # a fact split over two sentences
python run.py --show C3      # a short note buried in a long page
python run.py --show B1      # the same section name on every page
```
**Write one sentence:** why did the search miss each one? (Hint: what does the top chunk *not* contain?)

## 3. Fix it (9 min)
Open `run.py`. Edit only the places marked `YOUR FIX`:
1. `chunk_fixed()` - the overlap is ignored (the *chunks* column shows it). Make the next chunk start `size - overlap` words later.
2. `chunk_by_headings()` - each chunk must remember its page and section: `Title > Section: paragraph`.
3. After you have run again, set `MY_PICK` and `MY_REASON` (your recommendation, below).

## 4. Verify (3 min)
```
python run.py --check
```
**Verify that every check passes** (it also saves `results.json` - keep it).
Then run `python run.py --show B6` - this question is still missed by *every* config. Why? (Read the top chunks.)

## 5. Your recommendation (5 min)
Fill in `MY_PICK` and `MY_REASON` in `run.py` (at least 12 words: which config, why, and which question it still misses).
Run `python run.py --check` once more.

## 6. Write one sentence (2 min)
**What did I learn?** In particular: why did *structure-aware* win - what did the other chunks not know?

## Stretch - the same experiment with a real model
```
pip install sentence-transformers
python run.py --real
```
Does the order of the three configs change? Which of the failures disappear?

## Keep it
Keep `run.py` and `results.json`. In the last block you run a smaller version of this on **your own documents**.
